package id.ac.binus.webservicelg01;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import id.ac.binus.webservicelg01.model.FruitModel;

public class FruitAdapter extends RecyclerView.Adapter<FruitAdapter.FruitViewHolder>{
    List<FruitModel> fruitList;

    public FruitAdapter(List<FruitModel> fruitList){
        this.fruitList = fruitList;
    }

    @NonNull
    @Override
    public FruitAdapter.FruitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View myView = inflater.inflate(R.layout.item_fruit, parent, false);
        FruitViewHolder fruitHolder = new FruitViewHolder(myView);

        return fruitHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FruitAdapter.FruitViewHolder holder, int position) {
        FruitModel itemFruit = fruitList.get(position);
        String fruitName = itemFruit.getName();
        int calories = itemFruit.getNutritions().getCalories();

        holder.nameTV.setText(fruitName);
        holder.caloriesTV.setText("Calories: "+calories);
    }

    @Override
    public int getItemCount() {
        return fruitList.size();
    }

    public class FruitViewHolder extends RecyclerView.ViewHolder{
        TextView nameTV, caloriesTV;
        public FruitViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTV = itemView.findViewById(R.id.itemNameTV);
            caloriesTV = itemView.findViewById(R.id.itemCaloriesTV);
        }
    }
}
