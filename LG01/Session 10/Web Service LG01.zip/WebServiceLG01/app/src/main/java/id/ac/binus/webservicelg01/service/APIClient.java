package id.ac.binus.webservicelg01.service;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {
    public static Retrofit myRetrofit;
    public static String BASE_URL = "https://www.fruityvice.com/";

    public static Retrofit getMyRetrofit() {
        if (myRetrofit == null){
            myRetrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create()).build();
        }

        return myRetrofit;
    }
}
