package id.ac.binus.webservicelg01.service;

import java.util.List;

import id.ac.binus.webservicelg01.model.FruitModel;
import retrofit2.Call;
import retrofit2.http.GET;

public interface FruitInterface {

    @GET("api/fruit/all")
    Call<List<FruitModel>> getAllFruit();
}
