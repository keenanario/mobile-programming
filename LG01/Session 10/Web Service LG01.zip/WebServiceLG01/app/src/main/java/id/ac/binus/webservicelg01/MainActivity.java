package id.ac.binus.webservicelg01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import id.ac.binus.webservicelg01.model.FruitModel;
import id.ac.binus.webservicelg01.service.APIClient;
import id.ac.binus.webservicelg01.service.FruitInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView fruitRecycler;
    FruitInterface fruitAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fruitRecycler = findViewById(R.id.fruitRecycler);
        fruitAPI = APIClient.getMyRetrofit().create(FruitInterface.class);

        Call<List<FruitModel>> apiCall = fruitAPI.getAllFruit();
        apiCall.enqueue(new Callback<List<FruitModel>>() {
            @Override
            public void onResponse(Call<List<FruitModel>> call, Response<List<FruitModel>> response) {
                if (response.code() == 200){
                    List<FruitModel> fruitList = response.body();
                    FruitAdapter adapter = new FruitAdapter(fruitList);
                    LinearLayoutManager manager = new LinearLayoutManager(MainActivity.this);
                    fruitRecycler.setLayoutManager(manager);
                    fruitRecycler.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<FruitModel>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "failed", Toast.LENGTH_SHORT).show();
            }
        });

    }
}