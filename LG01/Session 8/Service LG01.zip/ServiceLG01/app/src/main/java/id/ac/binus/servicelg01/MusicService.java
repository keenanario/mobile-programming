package id.ac.binus.servicelg01;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

public class MusicService extends Service {
    MediaPlayer mp;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        String url = "https://www.dropbox.com/s/u4b0d5md7udw5k2/0013.%20Cinematic%20Ambient%20-%20AShamaluevMusic.mp3";
//        mp = MediaPlayer.create(this, Uri.parse(url));
//        try{
//            Notification notif = new NotificationCompat.Builder(this, "123").build();
//            int type = 0;
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
//                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
//            }
//
//            ServiceCompat.startForeground(this, 100, notif, type);
//        }catch (Exception e){
//            e.printStackTrace();
//        }

        mp = MediaPlayer.create(this, R.raw.music);
        mp.setLooping(true);
        mp.start();
        Toast.makeText(this, "Service berjalan", Toast.LENGTH_SHORT).show();

        return START_NOT_STICKY; // START_STICKY
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mp.stop();
        Toast.makeText(this, "Service selesai", Toast.LENGTH_SHORT).show();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
