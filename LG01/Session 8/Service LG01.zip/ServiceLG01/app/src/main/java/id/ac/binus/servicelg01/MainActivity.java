package id.ac.binus.servicelg01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button startBtn, stopBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);

        startBtn.setOnClickListener(this);
        stopBtn.setOnClickListener(this);

        startWorker();
    }

    void startWorker(){
        OneTimeWorkRequest oneTimeWorkRequest = new OneTimeWorkRequest.Builder(MyWorker.class).build();
        PeriodicWorkRequest periodicWorkRequest =
                new PeriodicWorkRequest.Builder(MyWorker.class, 30, TimeUnit.MINUTES).build();

        WorkManager manager = WorkManager.getInstance(this);
        manager.enqueue(oneTimeWorkRequest); //on time
        manager.enqueue(periodicWorkRequest); //periodic

        manager.enqueueUniquePeriodicWork("worker1", ExistingPeriodicWorkPolicy.KEEP, periodicWorkRequest);
    }

    @Override
    public void onClick(View v) {
        Intent serviceIntent = new Intent(MainActivity.this, MusicService.class);

        if (v == startBtn){
            startService(serviceIntent); //background
//            startForegroundService(serviceIntent); //foreground
        }else if(v == stopBtn){
            stopService(serviceIntent);
        }
    }
}