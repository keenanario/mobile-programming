package com.example.fragmentlh01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button firstBtn, secondBtn, pindahBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstBtn = findViewById(R.id.firstBtn);
        secondBtn = findViewById(R.id.secondBtn);
        pindahBtn = findViewById(R.id.pindahBtn);

        firstBtn.setOnClickListener(this);
        secondBtn.setOnClickListener(this);
        pindahBtn.setOnClickListener(this);

        loadFragment(new FirstFragment());
    }

    private void loadFragment(Fragment selectedFragment){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fragmentContainer, selectedFragment);
        transaction.commit();
    }

    @Override
    public void onClick(View v) {
        if (v == firstBtn){
            loadFragment(new FirstFragment());
        } else if (v == secondBtn) {
            loadFragment(new SecondFragment("Ini dari MainActivity"));
        } else if (v == pindahBtn) {
            startActivity(new Intent(MainActivity.this, DetailActivity.class));
        }
    }
}