package id.ac.binus.pertemuan7datapersistence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    TextView greetingTV;

    EditText filenameET, contentET;
    Button saveBtn, loadBtn;
    String filename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        greetingTV = findViewById(R.id.greetingTV);

        //ambil data dari shared preferences
        SharedPreferences sharedPref = getSharedPreferences("mySharedPref", MODE_PRIVATE);
        String username = sharedPref.getString("keyUsername", "Guest");

        String greetings = "Welcome, " + username + "!";
        greetingTV.setText(greetings);

        //save & load file
        filenameET = findViewById(R.id.filenameET);
        contentET = findViewById(R.id.contentET);
        saveBtn = findViewById(R.id.saveBtn);
        loadBtn = findViewById(R.id.loadBtn);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = contentET.getText().toString();
                filename = filenameET.getText().toString() + ".txt";

                try{
                    FileOutputStream fos = openFileOutput(filename, Context.MODE_PRIVATE);
                    fos.write(content.getBytes());
                    fos.close();

                    DatabaseHelper db = new DatabaseHelper(HomeActivity.this);
                    long result = db.insertFile(filename, content);
                    
                    if (result != -1){
                        Toast.makeText(HomeActivity.this, "Sqlite berhasil", Toast.LENGTH_SHORT).show();
                    }

                    Toast.makeText(HomeActivity.this, "File tersimpan", Toast.LENGTH_SHORT).show();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });

        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper db = new DatabaseHelper(HomeActivity.this);

                List<String> fileList = db.getAllFiles();

                filename = filenameET.getText().toString() + ".txt";
                try{
                    FileInputStream fis = openFileInput(filename);
                    byte[] buffer = new byte[fis.available()];
                    fis.read(buffer);

                    String content = new String(buffer);
                    contentET.setText(content);
                    fis.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }
}