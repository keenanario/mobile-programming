package id.ac.binus.pertemuan7datapersistence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText usernameET, passwordET;
    Button loginBtn;
    String username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameET = findViewById(R.id.loginUsernameET);
        passwordET = findViewById(R.id.loginPasswordET);
        loginBtn = findViewById(R.id.loginBtn);

        SharedPreferences sharedPref = getSharedPreferences("mySharedPref", MODE_PRIVATE);
        if (!sharedPref.getString("keyUsername", "").equals("")){
            Intent myIntent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(myIntent);
        }

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameET.getText().toString();
                password = passwordET.getText().toString();

                //simpan data ke shared preferences
                SharedPreferences.Editor myEditor = sharedPref.edit();
                myEditor.putString("keyUsername", username);
                myEditor.putString("keyPassword", password);
                myEditor.apply();

                Intent myIntent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(myIntent);
            }
        });
    }
}