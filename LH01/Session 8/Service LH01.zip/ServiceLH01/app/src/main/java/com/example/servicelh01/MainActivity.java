package com.example.servicelh01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button startBtn, stopBtn;
    Intent musicService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);

        startBtn.setOnClickListener(this);
        stopBtn.setOnClickListener(this);

        musicService = new Intent(MainActivity.this, MusicService.class);
    }

    @Override
    public void onClick(View v) {
        if (v == startBtn){
//            startService(musicService); //ini untuk background
            startForegroundService(musicService); //ini untuk foreground
        }
        else if(v == stopBtn){
            stopService(musicService);
        }
    }
}