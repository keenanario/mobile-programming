package com.example.servicelh01;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;

public class MusicService extends Service {
    MediaPlayer mp;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //untuk streaming lagu dari URL
        String url = "https://www.dropbox.com/s/u4b0d5md7udw5k2/0013.%20Cinematic%20Ambient%20-%20AShamaluevMusic.mp3";
        mp = MediaPlayer.create(this, Uri.parse(url)); //ini kalo mau dari URL

        //untuk streaming lagu dari file local di android project
//        mp = MediaPlayer.create(this, R.raw.music);
        mp.setLooping(true);
        mp.start();

        //tambahkan request permission untuk notifikasi
        //tambahkan request permission untuk foreground service
        //tambah fungsi create channel notification

        return START_NOT_STICKY; //START_STICKY
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mp.stop();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}